@javax.xml.bind.annotation.XmlSchema(namespace = "http://soap.edu/")
package edu.soap;
